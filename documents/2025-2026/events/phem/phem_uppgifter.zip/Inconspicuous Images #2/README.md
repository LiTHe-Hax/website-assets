Finally found a slime chunk, now we can make sticky pistons :D

I wish there was an easier way to see these chunks.



