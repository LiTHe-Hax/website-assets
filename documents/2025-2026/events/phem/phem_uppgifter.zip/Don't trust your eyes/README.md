There’s this person I know who’s extremely paranoid about Soviet spies spying on our data. He’s also very weird, he 3D-printed a raccoon and says he likes 3D objects (what a weirdo!). Anyway, he sent me this image. Can you see if there’s any message in it?

