You will never crack this code!



The format of the flag is "HAX{ascii\_text\_here}".

