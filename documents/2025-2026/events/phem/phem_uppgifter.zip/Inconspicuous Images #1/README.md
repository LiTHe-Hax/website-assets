Look at this cool ZIPPO lighter I found on eBay!



